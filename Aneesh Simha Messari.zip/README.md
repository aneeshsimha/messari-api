#messari-api
Messari Take Home Challenge
Aneesh Simha


This program requires Python3, pandas, numpy, requests, and functools library.

##Main Challenge
To run the program for the main challenge use the following command:

`python3 take_home.py`

The instructions to run the program will follow on the command line.

##Bonus Challenge

To run the program for the main challenge

`python3 bonus_take_home.py `

The instructions to run the program will follow on the command line.
